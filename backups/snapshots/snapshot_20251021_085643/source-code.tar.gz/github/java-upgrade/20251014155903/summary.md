
# Upgrade Java Project

## 🖥️ Project Information
- **Project path**: /Users/benh/Documents/StartAChapter
- **Java version**: 21
- **Build tool type**: Maven
- **Build tool path**: /Users/benh/.maven/maven-3.9.11/bin

## 🎯 Goals

- Upgrade Java to 21

## 🔀 Changes

### Test Changes
|     | Total | Passed | Failed | Skipped | Errors |
|-----|-------|--------|--------|---------|--------|
| Before | 36 | 35 | 1 | 0 | 0 |
| After | 36 | 36 | 0 | 0 | 0 |
### Dependency Changes


#### Upgraded Dependencies
| Dependency | Original Version | Current Version | Module |
|------------|------------------|-----------------|--------|
| org.springframework.boot:spring-boot-starter-web | 3.1.5 | 3.3.6 | campus-chapter-organizer |
| org.springframework.boot:spring-boot-starter-data-jpa | 3.1.5 | 3.3.6 | campus-chapter-organizer |
| org.springframework.boot:spring-boot-starter-validation | 3.1.5 | 3.3.6 | campus-chapter-organizer |
| org.springframework.boot:spring-boot-starter-thymeleaf | 3.1.5 | 3.3.6 | campus-chapter-organizer |
| com.h2database:h2 | 2.1.214 | 2.2.224 | campus-chapter-organizer |
| org.postgresql:postgresql | 42.6.0 | 42.7.7 | campus-chapter-organizer |
| org.springframework.boot:spring-boot-starter-test | 3.1.5 | 3.3.6 | campus-chapter-organizer |
| org.junit.jupiter:junit-jupiter | 5.9.3 | 5.10.5 | campus-chapter-organizer |
| org.mockito:mockito-core | 5.3.1 | 5.11.0 | campus-chapter-organizer |
| org.springframework.boot:spring-boot-devtools | 3.1.5 | 3.3.6 | campus-chapter-organizer |
| Java | 17 | 21 | Root Module |

### Code commits

All code changes have been committed to branch `appmod/java-upgrade-20251014155903`, here are the details:
20 files changed, 154 insertions(+), 7 deletions(-)

- 9a157ba -- Upgrade project to Java 21 using openrewrite.

- d073cd1 -- fix issues

- 71979b5 -- Fix CVE-2025-49146 by upgrading PostgreSQL driver to 42.7.7

- 933684e -- Fix test failure by setting correct member role in test setup
### Potential Issues

#### Behavior Changes
- [MemberServiceTest.java](../../../src/test/java/com/turningpoint/chapterorganizer/service/MemberServiceTest.java)
  - [Severity: **MINOR**] [Confidence: **MEDIUM**] This is a test fix that ensures the test member has the correct role before testing role-based filtering. This improves test correctness and may prevent false test failures, but does not change production code behavior.
  - [Severity: **MINOR**] [Confidence: **LOW**] The test now properly sets up the test member's role to match the expected behavior being tested. This ensures the test member actually has the PRESIDENT role when testing the `getMembersByRole` functionality, making the test more accurate and reliable.
