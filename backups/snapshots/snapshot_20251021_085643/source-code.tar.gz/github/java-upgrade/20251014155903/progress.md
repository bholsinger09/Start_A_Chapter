# Upgrade Progress

  ### ✅ Generate Upgrade Plan [View Log](logs/1.generatePlan.log)

  ### ❗ Setup Development Environment [View Log](logs/2.setupEnvironment.log)
  
  <details>
      <summary>[ click to toggle details ]</summary>
  
  #### Errors
  - Project compile failed with 1 errors. The project must be compileable before upgrading it, please fix the errors first and then invoke tool #setup\_development\_environment\_for\_upgrade again to setup development environment: - cannot find symbol symbol:   class EventService location: class com.turningpoint.chapterorganizer.service.EventServiceTest   \`\`\`   [ERROR] /Users/benh/Documents/StartAChapter/src/test/java/com/turningpoint/chapterorganizer/service/EventServiceTest.java:[33,13] cannot find symbol   [ERROR]   symbol:   class EventService   [ERROR]   location: class com.turningpoint.chapterorganizer.service.EventServiceTest   \`\`\`
  
  
  - ###
    ### ✅ Install JDK 21
  
  </details>

  ### ✅ PreCheck [View Log](logs/3.precheck.log)
  
  <details>
      <summary>[ click to toggle details ]</summary>
  
  - ###
    ### ❗ Precheck - Build project [View Log](logs/3.1.precheck-buildProject.log)
    
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### Command
    mvn clean test-compile -q -B -fn
    
    #### Errors
    - cannot find symbol symbol:   class EventService location: class com.turningpoint.chapterorganizer.service.EventServiceTest
      ```
      [ERROR] /Users/benh/Documents/StartAChapter/src/test/java/com/turningpoint/chapterorganizer/service/EventServiceTest.java:[33,13] cannot find symbol
      [ERROR]   symbol:   class EventService
      [ERROR]   location: class com.turningpoint.chapterorganizer.service.EventServiceTest
      ```
    
    
    
    </details>
  
  </details>

  ### ✅ Setup Development Environment [View Log](logs/4.setupEnvironment.log)

  ### ✅ PreCheck [View Log](logs/5.precheck.log)
  
  <details>
      <summary>[ click to toggle details ]</summary>
  
  - ###
    ### ✅ Precheck - Build project [View Log](logs/5.1.precheck-buildProject.log)
    
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### Command
    mvn clean test-compile -q -B -fn
    
    
    
    </details>
  
    ### ✅ Precheck - Validate CVEs [View Log](logs/5.2.precheck-validateCves.log)
    
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### CVE issues
    - Dependency `com.h2database:h2` has **1** known CVEs:
      - [CVE-2022-45868](https://github.com/advisories/GHSA-22wj-vf5f-wrvj): Password exposure in H2 Database 
        - **Severity**: **HIGH**
        - **Details**: The web-based admin console in H2 Database Engine through 2.1.214 can be started via the CLI with the argument -webAdminPassword, which allows the user to specify the password in cleartext for the web admin console. Consequently, a local user (or an attacker that has obtained local access through some means) would be able to discover the password by listing processes and their arguments. NOTE: the vendor states "This is not a vulnerability of H2 Console ... Passwords should never be passed on the command line and every qualified DBA or system administrator is expected to know that."
    - Dependency `org.postgresql:postgresql` has **1** known CVEs:
      - [CVE-2024-1597](https://github.com/advisories/GHSA-24rp-q3w6-vc56): org.postgresql:postgresql vulnerable to SQL Injection via line comment generation
        - **Severity**: **CRITICAL**
        - **Details**: # Impact
          SQL injection is possible when using the non-default connection property `preferQueryMode=simple` in combination with application code that has a vulnerable SQL that negates a parameter value.
          
          There is no vulnerability in the driver when using the default query mode. Users that do not override the query mode are not impacted.
          
          # Exploitation
          
          To exploit this behavior the following conditions must be met:
          
          1. A placeholder for a numeric value must be immediately preceded by a minus (i.e. `-`)
          1. There must be a second placeholder for a string value after the first placeholder on the same line. 
          1. Both parameters must be user controlled.
          
          The prior behavior of the driver when operating in simple query mode would inline the negative value of the first parameter and cause the resulting line to be treated as a `--` SQL comment. That would extend to the beginning of the next parameter and cause the quoting of that parameter to be consumed by the comment line. If that string parameter includes a newline, the resulting text would appear unescaped in the resulting SQL.
          
          When operating in the default extended query mode this would not be an issue as the parameter values are sent separately to the server. Only in simple query mode the parameter values are inlined into the executed SQL causing this issue.
          
          # Example
          
          ```java
          PreparedStatement stmt = conn.prepareStatement("SELECT -?, ?");
          stmt.setInt(1, -1);
          stmt.setString(2, "\nWHERE false --");
          ResultSet rs = stmt.executeQuery();
          ```
          
          The resulting SQL when operating in simple query mode would be:
          
          ```sql
          SELECT --1,'
          WHERE false --'
          ```
          
          The contents of the second parameter get injected into the command. Note how both the number of result columns and the WHERE clause of the command have changed. A more elaborate example could execute arbitrary other SQL commands.
          
          # Patch
          Problem will be patched upgrade to 42.7.2, 42.6.1, 42.5.5, 42.4.4, 42.3.9, 42.2.28, 42.2.28.jre7
          
          The patch fixes the inlining of parameters by forcing them all to be serialized as wrapped literals. The SQL in the prior example would be transformed into:
          
          ```sql
          SELECT -('-1'::int4), ('
          WHERE false --')
          ```
          
          # Workarounds
          Do not use the connection property`preferQueryMode=simple`. (*NOTE: If you do not explicitly specify a query mode then you are using the default of `extended` and are not impacted by this issue.*)
    
    
    
    </details>
  
    ### ✅ Precheck - Run tests [View Log](logs/5.3.precheck-runTests.log)
    
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### Test result
    | Total | Passed | Failed | Skipped | Errors |
    |-------|--------|--------|---------|--------|
    | 36 | 35 | 1 | 0 | 0 |
    
    
    
    </details>
  
  </details>

  ### ✅ Upgrade project to Java 21
  
  <details>
      <summary>[ click to toggle details ]</summary>
  
  - ###
    ### ❗ Upgrade using OpenRewrite [View Log](logs/6.1.upgradeProjectUsingOpenRewrite.log)
    21 files changed, 176 insertions(+), 0 deletions(-)
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### Recipes
    - [org.openrewrite.java.migrate.UpgradeToJava21](https://docs.openrewrite.org/recipes/java/migrate/UpgradeToJava21)
    
    #### Errors
    Failed to run command: "mvn -B org.openrewrite.maven:rewrite-maven-plugin:5.47.3:run -Drewrite.activeRecipes=org.openrewrite.java.migrate.UpgradeToJava21 -Drewrite.recipeArtifactCoordinates=org.openrewrite.recipe:rewrite-migrate-java:2.31.1" with error code 1 
      ```
      Error: Failed to run command: "mvn -B org.openrewrite.maven:rewrite-maven-plugin:5.47.3:run -Drewrite.activeRecipes=org.openrewrite.java.migrate.UpgradeToJava21 -Drewrite.recipeArtifactCoordinates=org.openrewrite.recipe:rewrite-migrate-java:2.31.1" with error code 1
      
          at cLt.run (/Users/benh/.vscode/extensions/vscjava.vscode-java-upgrade-1.6.1/dist/extension.js:437:2530)
          at processTicksAndRejections (node:internal/process/task\_queues:105:5)
          at j7e.runOpenRewriteRecipes (/Users/benh/.vscode/extensions/vscjava.vscode-java-upgrade-1.6.1/dist/extension.js:553:1537)
          at w$e.doInvoke (/Users/benh/.vscode/extensions/vscjava.vscode-java-upgrade-1.6.1/dist/extension.js:1173:7)
          at w$e.invoke (/Users/benh/.vscode/extensions/vscjava.vscode-java-upgrade-1.6.1/dist/extension.js:463:3339)
          at eUt.invoke (/Users/benh/.vscode/extensions/vscjava.vscode-java-upgrade-1.6.1/dist/extension.js:1515:122)
          at Mq.$invokeTool (file:///Applications/Visual%20Studio%20Code.app/Contents/Resources/app/out/vs/workbench/api/node/extensionHostProcess.js:181:3046)
      ```
    
    
    
    </details>
  
    ### ✅ Upgrade using Agent [View Log](logs/6.2.upgradeProjectUsingAgent.log)
    1 file changed, 6 insertions(+), 6 deletions(-)
  
    ### ✅ Build Project [View Log](logs/6.3.buildProject.log)
    Build result: 100% Java files compiled
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### Command
    `mvn clean test-compile -q -B -fn`
    
    
    
    </details>
  
  </details>

  ### ✅ Validate & Fix
  
  <details>
      <summary>[ click to toggle details ]</summary>
  
  - ###
    ### ✅ Validate CVEs [View Log](logs/7.1.validateCves.log)
    
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### Checked Dependencies
      - org.springframework.boot:spring-boot-starter-web:3.3.6
      - org.springframework.boot:spring-boot-starter-data-jpa:3.3.6
      - org.springframework.boot:spring-boot-starter-validation:3.3.6
      - org.springframework.boot:spring-boot-starter-thymeleaf:3.3.6
      - com.h2database:h2:2.2.224
      - org.postgresql:postgresql:42.7.4
      - org.springframework.boot:spring-boot-starter-test:3.3.6
      - org.junit.jupiter:junit-jupiter:5.10.5
      - org.mockito:mockito-core:5.11.0
      - org.springframework.boot:spring-boot-devtools:3.3.6
    
    #### CVE issues
    - Dependency `org.postgresql:postgresql` has **1** known CVEs:
      - [CVE-2025-49146](https://github.com/advisories/GHSA-hq9p-pm7w-8p54): pgjdbc Client Allows Fallback to Insecure Authentication Despite channelBinding=require Configuration
        - **Severity**: **HIGH**
        - **Details**: ### Impact
          When the PostgreSQL JDBC driver is configured with channel binding set to `required` (default value is `prefer`), the driver would incorrectly allow connections to proceed with authentication methods that do not support channel binding (such as password, MD5, GSS, or SSPI  authentication). This could allow a man-in-the-middle attacker to intercept connections that users believed were protected by channel binding requirements.
          
          ### Patches
          TBD
          
          ### Workarounds
          
          Configure `sslMode=verify-full` to prevent MITM attacks.
          
          ### References
          
          * https://www.postgresql.org/docs/current/sasl-authentication.html#SASL-SCRAM-SHA-256
          * https://datatracker.ietf.org/doc/html/rfc7677
          * https://datatracker.ietf.org/doc/html/rfc5802
    
    
    
    </details>
  
    ### ✅ Fix CVE Issues [View Log](logs/7.2.fixCveIssues.log)
    22 files changed, 3 insertions(+), 33 deletions(-)
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### Code changes
    - Fix CVE-2025-49146 in PostgreSQL JDBC driver
      - Upgrade org.postgresql:postgresql to version 42.7.7 to address HIGH severity security vulnerability
    
    
    
    </details>
  
    ### ✅ Build Project [View Log](logs/7.3.buildProject.log)
    Build result: 100% Java files compiled
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### Command
    `mvn clean test-compile -q -B -fn`
    
    
    
    </details>
  
    ### ✅ Validate CVEs [View Log](logs/7.4.validateCves.log)
    
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### Checked Dependencies
      - org.springframework.boot:spring-boot-starter-web:3.3.6
      - org.springframework.boot:spring-boot-starter-data-jpa:3.3.6
      - org.springframework.boot:spring-boot-starter-validation:3.3.6
      - org.springframework.boot:spring-boot-starter-thymeleaf:3.3.6
      - com.h2database:h2:2.2.224
      - org.postgresql:postgresql:42.7.7
      - org.springframework.boot:spring-boot-starter-test:3.3.6
      - org.junit.jupiter:junit-jupiter:5.10.5
      - org.mockito:mockito-core:5.11.0
      - org.springframework.boot:spring-boot-devtools:3.3.6
    
    
    
    </details>
  
    ### ✅ Validate Code Behavior Changes [View Log](logs/7.5.validateBehaviorChanges.log)
  
    ### ❗ Run Tests [View Log](logs/7.6.runTests.log)
    
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### Test result
    | Total | Passed | Failed | Skipped | Errors |
    |-------|--------|--------|---------|--------|
    | 36 | 35 | 1 | 0 | 0 |
    
    #### Errors
    - &#10;expected: President&#10; but was: Member
      ```
      org.opentest4j.AssertionFailedError: 
      
      expected: President
       but was: Member
      	at java.base/jdk.internal.reflect.DirectConstructorHandleAccessor.newInstance(DirectConstructorHandleAccessor.java:62)
      	at java.base/java.lang.reflect.Constructor.newInstanceWithCaller(Constructor.java:502)
      	at com.turningpoint.chapterorganizer.service.MemberServiceTest.getMembersByRole\_ShouldReturnMembersWithSpecificRole(MemberServiceTest.java:164)
      	at java.base/java.lang.reflect.Method.invoke(Method.java:580)
      	at java.base/java.util.ArrayList.forEach(ArrayList.java:1596)
      	at java.base/java.util.ArrayList.forEach(ArrayList.java:1596)
      
      ```
    
    
    
    </details>
  
    ### ✅ Fix Test Errors/Failures [View Log](logs/7.7.fixTestErrors.log)
    2 files changed, 1 insertion(+), 0 deletions(-)
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### Code changes
    - Fix failing test in MemberServiceTest
      - Add testMember.setRole(MemberRole.PRESIDENT) in getMembersByRole_ShouldReturnMembersWithSpecificRole test to match the expected assertion
    
    
    
    </details>
  
    ### ✅ Build Project [View Log](logs/7.8.buildProject.log)
    Build result: 100% Java files compiled
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### Command
    `mvn clean test-compile -q -B -fn`
    
    
    
    </details>
  
    ### ✅ Validate CVEs [View Log](logs/7.9.validateCves.log)
    
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### Checked Dependencies
      - org.springframework.boot:spring-boot-starter-web:3.3.6
      - org.springframework.boot:spring-boot-starter-data-jpa:3.3.6
      - org.springframework.boot:spring-boot-starter-validation:3.3.6
      - org.springframework.boot:spring-boot-starter-thymeleaf:3.3.6
      - com.h2database:h2:2.2.224
      - org.postgresql:postgresql:42.7.7
      - org.springframework.boot:spring-boot-starter-test:3.3.6
      - org.junit.jupiter:junit-jupiter:5.10.5
      - org.mockito:mockito-core:5.11.0
      - org.springframework.boot:spring-boot-devtools:3.3.6
    
    
    
    </details>
  
    ### ✅ Validate Code Behavior Changes [View Log](logs/7.10.validateBehaviorChanges.log)
    
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### Behavior changes
    Code behavior changes are detected in **1** files, here are the details:
    - [MemberServiceTest.java](../../../src/test/java/com/turningpoint/chapterorganizer/service/MemberServiceTest.java)
      - [Severity: **MINOR**] [Confidence: **LOW**] This change fixes a test setup issue by ensuring the test member has the proper role before testing role-based functionality. This improves test reliability and makes the test behavior more predictable.
        - Before: The test method `getMembersByRole_ShouldReturnMembersWithSpecificRole` was testing member role functionality without properly setting up the test member's role, potentially leading to inconsistent test behavior.
        - After: The test method now properly sets `testMember.setRole(MemberRole.PRESIDENT)` before executing the test logic, ensuring the test member has the correct role for the test scenario.
      - [Severity: **MINOR**] [Confidence: **LOW**] The test has been improved to explicitly set the member role before testing. This makes the test more robust and ensures the member actually has the expected role when testing role filtering. This is a test improvement that makes the test behavior more predictable and reliable.
        - Before: The test method `getMembersByRole_ShouldReturnMembersWithSpecificRole()` creates a test scenario without explicitly setting the member's role before testing role-based filtering.
        - After: The test method now explicitly sets `testMember.setRole(MemberRole.PRESIDENT)` before testing role-based filtering functionality.
    
    
    
    </details>
  
    ### ✅ Run Tests [View Log](logs/7.11.runTests.log)
    
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### Test result
    | Total | Passed | Failed | Skipped | Errors |
    |-------|--------|--------|---------|--------|
    | 36 | 36 | 0 | 0 | 0 |
    
    
    
    </details>
  
  </details>

  ### ✅ Summarize Upgrade [View Log](logs/8.summarizeUpgrade.log)