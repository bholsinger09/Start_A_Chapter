# Upgrade Progress

  ### ❗ Generate Upgrade Plan [View Log](logs/1.generatePlan.log)
  
  <details>
      <summary>[ click to toggle details ]</summary>
  
  #### Errors
  - Failed to get git status for /Users/benh/Documents/StartAChapter: fatal: not a git repository (or any of the parent directories): .git
  
  
  - ###
    ### ✅ Install JDK 17
  
    ### ✅ Install Maven
  
  </details>