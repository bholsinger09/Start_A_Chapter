// Mock for static file imports
module.exports = 'test-file-stub'