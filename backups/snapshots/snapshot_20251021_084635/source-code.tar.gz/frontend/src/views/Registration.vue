<template>
  <div>
    <Registration />
  </div>
</template>

<script>
import Registration from '../components/Registration.vue'

export default {
  name: 'RegistrationView',
  components: {
    Registration
  }
}
</script>