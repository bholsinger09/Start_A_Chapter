package com.turningpoint.chapterorganizer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CampusChapterOrganizerApplication {

    public static void main(String[] args) {
        SpringApplication.run(CampusChapterOrganizerApplication.class, args);
    }
}